import pyttsx3
import tkinter as tk

def text_to_speech():
    text = text_entry.get("1.0", tk.END)
    rate = int(rate_entry.get() or 200)
    voice = voice_var.get()

    engine = pyttsx3.init()
    voices = engine.getProperty('voices')
    if voice == 'female':
        engine.setProperty('voice', voices[1].id)
    else:
        engine.setProperty('voice', voices[0].id)
    
    engine.setProperty('rate', rate)
    engine.say(text)
    engine.runAndWait()

# Create GUI
root = tk.Tk()
root.title("Text-to-Speech Converter")

text_label = tk.Label(root, text="Enter Text:")
text_label.pack()
text_entry = tk.Text(root, height=10, width=50)
text_entry.pack()

rate_label = tk.Label(root, text="Speech Rate:")
rate_label.pack()
rate_entry = tk.Entry(root)
rate_entry.pack()

voice_label = tk.Label(root, text="Voice:")
voice_label.pack()
voice_var = tk.StringVar(value='female')
voice_male = tk.Radiobutton(root, text='Male', variable=voice_var, value='male')
voice_female = tk.Radiobutton(root, text='Female', variable=voice_var, value='female')
voice_male.pack()
voice_female.pack()

convert_button = tk.Button(root, text="Convert to Speech", command=text_to_speech)
convert_button.pack()

root.mainloop()
